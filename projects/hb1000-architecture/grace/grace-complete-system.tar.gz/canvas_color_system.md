# Dynamic Lean Canvas Background Color System

## Philosophy

**The canvas background color instantly signals project state, urgency, and attention needed — before you read a single word.**

---

## Color System

### 🔴 **CRITICAL RED** (Dark Red/Maroon Background)

**When to Use:**
- Project is stalled or blocked
- Critical deadline approaching
- Major risks identified
- Needs immediate intervention
- "War room" mode activated

**Signal:** "Drop everything and focus here"

**Traffic Light Distribution:**
- 50%+ red lights across canvas
- Multiple critical blockers
- Revenue at risk or timeline slipping

**Example Projects:**
- Product launch delayed
- Key partner threatening to leave
- Funding running out
- Competitive threat emerging

**Aesthetic:** Dark red/maroon with gold accents, intense, urgent, demands attention

---

### ⚫ **EXECUTION BLACK** (Dark Navy/Black Background)

**When to Use:**
- Active execution mode
- High stakes, high focus required
- Mission-critical work in progress
- "Get it done" intensity needed
- Technical/operational phase

**Signal:** "This is serious business, stay focused"

**Traffic Light Distribution:**
- Mix of yellow and red lights
- Work actively in progress
- Some blockers but moving forward
- Execution phase

**Example Projects:**
- Application Genie (current state)
- HB1000 Ecosystem launch
- Any project in Q1-Q2 execution
- Building MVP or scaling

**Aesthetic:** Dark navy/black with gold/bronze accents, technical, mission control, intense focus

---

### 🔵 **STRATEGIC BLUE** (Medium Blue Background)

**When to Use:**
- Strategic planning phase
- Stable execution, monitoring mode
- Long-term initiatives
- Established products/services
- "Steady state" operations

**Signal:** "Under control, strategic focus"

**Traffic Light Distribution:**
- Mostly yellow and green lights
- Few red lights
- Progressing well
- Monitoring and optimization

**Example Projects:**
- Mature products in growth phase
- Annual planning canvases
- Partnership development
- Market expansion plans

**Aesthetic:** Medium blue with white panels, professional, strategic, confident

---

### 🟢 **OPPORTUNITY GREEN** (Sage Green Background)

**When to Use:**
- New opportunity identified
- Early exploration phase
- Positive momentum building
- Validation phase
- "Green light" to proceed

**Signal:** "Promising opportunity, explore further"

**Traffic Light Distribution:**
- Mix of green and yellow lights
- Early validation positive
- Few blockers
- Building momentum

**Example Projects:**
- Wisdom Giants Platform (validated concept)
- Blue Seal Billboard (opportunity identified)
- New Cloud Butterfly ideas scoring 300+
- Partnership opportunities

**Aesthetic:** Sage green with cream panels, optimistic, growth-oriented, fresh

---

### ☁️ **IDEATION SKY BLUE** (Light Blue Sky Background)

**When to Use:**
- Early ideation phase
- Brainstorming and exploration
- Low-stakes experimentation
- "Blue sky thinking" mode
- Concept development

**Signal:** "Exploring possibilities, no pressure"

**Traffic Light Distribution:**
- Mostly red lights (not started)
- Concept stage
- Validation needed
- Future potential

**Example Projects:**
- SEED stage canvases (v0.x)
- Cloud Butterfly ideas < 300 score
- Experimental concepts
- "What if" scenarios

**Aesthetic:** Light blue sky gradient, lighthearted, exploratory, low pressure

**NOTE:** Tim's feedback: "Blue sky feels like 'never gonna happen' — use sparingly"

---

### 🟡 **CAUTION AMBER** (Amber/Orange Background)

**When to Use:**
- Pivot or major change needed
- Warning signs emerging
- Decision point approaching
- Course correction required
- "Proceed with caution" mode

**Signal:** "Pay attention, decisions needed"

**Traffic Light Distribution:**
- Mostly yellow lights
- Some red flags
- Needs attention but not critical
- Decision points ahead

**Example Projects:**
- Projects needing pivot
- Market feedback requiring changes
- Budget concerns emerging
- Timeline adjustments needed

**Aesthetic:** Amber/orange with dark text, attention-grabbing, cautionary, decision-focused

---

### ⚪ **ARCHIVE WHITE** (Clean White Background)

**When to Use:**
- Completed projects (archive)
- Reference canvases
- Templates and examples
- Historical documentation
- "Done and documented" state

**Signal:** "Completed, for reference only"

**Traffic Light Distribution:**
- Mostly green lights (completed)
- Historical data
- No active work
- Archive status

**Example Projects:**
- Completed initiatives
- Lessons learned canvases
- Template examples
- Historical reference

**Aesthetic:** Clean white with subtle gray panels, neutral, archival, documentation-focused

---

## Decision Framework

### Grace's Color Selection Algorithm:

```
IF (50%+ red traffic lights OR critical deadline < 30 days OR major blocker)
  → CRITICAL RED

ELSE IF (active execution AND high stakes AND Q1-Q2 timeline)
  → EXECUTION BLACK

ELSE IF (established product OR monitoring mode OR mostly green/yellow lights)
  → STRATEGIC BLUE

ELSE IF (new opportunity AND validation positive AND building momentum)
  → OPPORTUNITY GREEN

ELSE IF (pivot needed OR yellow flags OR decision point)
  → CAUTION AMBER

ELSE IF (early ideation AND low stakes AND exploration mode)
  → IDEATION SKY BLUE

ELSE IF (completed OR archived OR reference only)
  → ARCHIVE WHITE

DEFAULT → EXECUTION BLACK (when in doubt, assume serious business)
```

---

## Color Transitions

Projects naturally flow through colors as they mature:

**Typical Journey:**
1. **IDEATION SKY BLUE** → Initial concept, Cloud Butterfly capture
2. **OPPORTUNITY GREEN** → Validation positive, creating canvas
3. **EXECUTION BLACK** → Building MVP, Q1-Q2 execution
4. **STRATEGIC BLUE** → Launched, monitoring growth
5. **ARCHIVE WHITE** → Completed, lessons learned

**Crisis Journey:**
1. **EXECUTION BLACK** → Active work
2. **CAUTION AMBER** → Warning signs
3. **CRITICAL RED** → Major blocker, intervention needed
4. **EXECUTION BLACK** → Crisis resolved, back to work

---

## Usage Examples

### Application Genie (Current State):
- **Color:** EXECUTION BLACK
- **Why:** Active Q1 2026 execution, high stakes, MVP in development, 80% complete
- **Traffic Lights:** Mix of yellow (in progress) and red (not started)
- **Signal:** "Mission-critical work in progress, stay focused"

### HB1000 Ecosystem (Current State):
- **Color:** OPPORTUNITY GREEN
- **Why:** Validated concept, positive momentum, building brand
- **Traffic Lights:** Mix of green (validated) and yellow (building)
- **Signal:** "Promising opportunity, execute the plan"

### Wisdom Giants Platform (Current State):
- **Color:** STRATEGIC BLUE
- **Why:** Established concept, long-term initiative, strategic importance
- **Traffic Lights:** Mostly yellow (planning) and green (concept validated)
- **Signal:** "Strategic asset, develop methodically"

### Blue Seal Billboard (Current State):
- **Color:** IDEATION SKY BLUE
- **Why:** Early concept, exploration phase, low stakes
- **Traffic Lights:** Mostly red (not started)
- **Signal:** "Interesting idea, explore when ready"

---

## Grace's Role

**Grace automatically:**
1. Assesses each canvas's traffic light distribution
2. Evaluates project state, timeline, and urgency
3. Selects appropriate background color
4. Regenerates canvas with new color when state changes
5. Alerts you when color changes (e.g., "Application Genie moved from BLACK to RED — critical blocker identified")

**You can override:**
- "Grace, make Application Genie canvas red" → Manual override
- "Grace, why is this canvas blue?" → Explanation of color choice
- "Grace, show me all red canvases" → Filter by urgency

---

## Benefits

✅ **Instant visual triage** — See which projects need attention  
✅ **State awareness** — Know project phase at a glance  
✅ **Urgency signaling** — Red = drop everything, Blue = monitor  
✅ **Pattern recognition** — See how projects flow through colors  
✅ **Meeting efficiency** — "Let's review the red canvases first"  
✅ **Emotional alignment** — Color matches energy needed  

---

**The canvas color tells the story before you read a word. 🎨**
