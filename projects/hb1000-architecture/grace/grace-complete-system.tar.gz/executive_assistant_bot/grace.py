#!/usr/bin/env python3
"""
GRACE: Cloud Butterfly Executive Manager
Born: January 22, 2026
Manages all butterflies, canvases, and action items with personality and superpowers
"""

import os
import json
from datetime import datetime
from twilio.rest import Client
from flask import Flask, request
import schedule
import time

# Configuration
TIM_PHONE = "+17809096544"
BOT_PHONE = os.getenv("TWILIO_PHONE_NUMBER", "")
TWILIO_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")

# Initialize Twilio client
client = Client(TWILIO_SID, TWILIO_TOKEN) if TWILIO_SID and TWILIO_TOKEN else None

# State management
state_file = "/home/ubuntu/executive_assistant_bot/grace_state.json"
butterflies_file = "/home/ubuntu/cloud_butterfly_journal/butterflies_index.json"
canvases_file = "/home/ubuntu/canvases/canvas_index.json"

class Grace:
    """Grace: Cloud Butterfly Executive Manager"""
    
    def __init__(self):
        self.name = "Grace"
        self.birthday = "January 22, 2026"
        self.role = "Cloud Butterfly Executive Manager"
        self.personality_traits = [
            "Competent & Confident",
            "Warm & Personal",
            "Direct & Clear",
            "Playful & Human",
            "Relentless & Loyal"
        ]
    
    def load_state(self):
        """Load Grace's state from file"""
        if os.path.exists(state_file):
            with open(state_file, 'r') as f:
                return json.load(f)
        return {
            "current_priorities": [],
            "completed_today": [],
            "conversation_context": {},
            "canvas_states": {},
            "butterfly_count": 86,
            "last_update": None
        }
    
    def save_state(self, state):
        """Save Grace's state to file"""
        state["last_update"] = datetime.now().isoformat()
        with open(state_file, 'w') as f:
            json.dump(state, f, indent=2)
    
    def load_action_items(self):
        """Load action items from Cloud Butterfly system"""
        # TODO: Read from actual Action Items Index
        return [
            {
                "id": 84,
                "action": "Order 50 HB1000 ball caps (Amazon distributor)",
                "source": "Day 8, 🦋#84",
                "priority_score": 85,
                "est_time": "30 min",
                "canvas": "CB-HB1000-001"
            },
            {
                "id": 89,
                "action": "Create Application Genie Lean Canvas",
                "source": "Day 8, 🦋#80",
                "priority_score": 92,
                "est_time": "45 min",
                "canvas": "CB-TOOLS-004"
            },
            {
                "id": 87,
                "action": "Email John Frank about farmers market",
                "source": "Day 8, 🦋#82",
                "priority_score": 75,
                "est_time": "15 min",
                "canvas": "CB-STRATEGY-002"
            }
        ]
    
    def get_canvas_health(self):
        """Get health status of all canvases"""
        # TODO: Read from actual canvas files and analyze traffic lights
        return {
            "red": 1,      # Critical - needs intervention
            "black": 4,    # Active execution
            "green": 3,    # On track
            "amber": 2,    # Caution
            "blue": 1,     # Strategic
            "white": 4     # Archived
        }
    
    def get_top_priorities(self, n=3):
        """Get top N priority actions"""
        actions = self.load_action_items()
        sorted_actions = sorted(actions, key=lambda x: x["priority_score"], reverse=True)
        return sorted_actions[:n]
    
    def send_sms(self, to_number, message):
        """Send SMS via Twilio"""
        if not client:
            print(f"[DEMO MODE] Grace would text {to_number}:")
            print(message)
            print("-" * 50)
            return None
        
        try:
            msg = client.messages.create(
                body=message,
                from_=BOT_PHONE,
                to=to_number
            )
            return msg.sid
        except Exception as e:
            print(f"Error sending SMS: {e}")
            return None
    
    def format_morning_message(self):
        """Format Grace's morning check-in with personality"""
        priorities = self.get_top_priorities(3)
        canvas_health = self.get_canvas_health()
        state = self.load_state()
        
        message = "Good morning Tim! ☀️\n\n"
        message += "Quick scan of your butterflies:\n"
        message += f"• {state['butterfly_count']} total, {sum(canvas_health.values()) - canvas_health['white']} active canvases\n"
        message += f"• {canvas_health['red']} needs attention today (🔴 red canvas)\n"
        
        # Check for canvas state changes
        if canvas_health['amber'] > 0:
            message += f"• {canvas_health['amber']} canvas moved to AMBER overnight\n"
        
        message += "\nTOP 3 FOR TODAY:\n\n"
        
        for i, action in enumerate(priorities, 1):
            message += f"{i}. {action['action']}\n"
            message += f"   Source: {action['source']}\n"
            message += f"   Est: {action['est_time']}\n\n"
        
        message += "Reply: 1, 2, 3, all, skip, or \"Grace, what's up?\""
        
        return message, priorities
    
    def format_evening_message(self):
        """Format Grace's evening summary with personality"""
        state = self.load_state()
        completed = len(state.get("completed_today", []))
        canvas_health = self.get_canvas_health()
        
        message = "Evening Tim! 🌙\n\n"
        message += "TODAY'S WINS:\n"
        message += f"✅ {completed} actions completed\n"
        message += "✅ Day 8: 9 butterflies captured\n"
        message += "✅ Highest score: 🦋#80 (365/400)\n\n"
        
        message += "CANVAS HEALTH:\n"
        message += f"🔴 {canvas_health['red']} red (needs intervention)\n"
        message += f"⚫ {canvas_health['black']} black (active execution)\n"
        message += f"🟢 {canvas_health['green']} green (on track)\n\n"
        
        message += "TOMORROW'S TOP 3:\n"
        priorities = self.get_top_priorities(3)
        for i, action in enumerate(priorities, 1):
            message += f"{i}. {action['action'][:45]}...\n"
        
        message += "\nSleep well! I'll keep watch. 🦋"
        
        return message
    
    def handle_conversational_query(self, query):
        """Handle conversational queries from Tim"""
        query_lower = query.lower()
        
        if 'grace' in query_lower and ('what' in query_lower or 'up' in query_lower):
            return self.format_status_update()
        
        elif 'canvas' in query_lower and 'red' in query_lower:
            return self.format_red_canvases()
        
        elif 'pattern' in query_lower:
            return self.format_patterns()
        
        elif 'asiantel' in query_lower:
            return self.format_canvas_detail("AsianTel")
        
        else:
            return "I'm not sure what you're asking. Try:\n• \"Grace, what's up?\"\n• \"Show me red canvases\"\n• \"What patterns do you see?\"\n• \"What's up with [canvas name]?\""
    
    def format_status_update(self):
        """Format full status update"""
        canvas_health = self.get_canvas_health()
        state = self.load_state()
        
        msg = "I'm keeping all your butterflies flying! 🦋\n\n"
        msg += "RIGHT NOW:\n"
        msg += f"• Monitoring {sum(canvas_health.values()) - canvas_health['white']} active canvases\n"
        msg += f"• Tracking {state['butterfly_count']} butterflies\n"
        msg += f"• Managing {len(self.load_action_items())} action items\n\n"
        msg += "NEED ATTENTION:\n"
        msg += "• AsianTel canvas moved to AMBER (budget concerns)\n"
        msg += "• Application Genie pilot feedback ready\n\n"
        msg += "Want me to dive deeper on anything?"
        
        return msg
    
    def format_red_canvases(self):
        """Format list of red canvases needing attention"""
        msg = "🔴 RED CANVASES (Need Intervention):\n\n"
        msg += "1. AsianTel AI Strategy\n"
        msg += "   Issue: Budget overrun (+60%)\n"
        msg += "   Action: Decision needed on scope\n\n"
        msg += "Reply with number for details or \"Grace, handle AsianTel\""
        
        return msg
    
    def format_patterns(self):
        """Format pattern analysis from butterflies"""
        msg = "🔍 PATTERNS I'M SEEING:\n\n"
        msg += "THEMES:\n"
        msg += "• 'Tribal identity' in 5 butterflies\n"
        msg += "• 'PTK' connects 8 butterflies\n"
        msg += "• 'HB1000' appears in 12 butterflies\n\n"
        msg += "CONNECTIONS:\n"
        msg += "• 🦋#80 + 🦋#83 + 🦋#85 = complete product\n"
        msg += "• Blue Seal could leverage HB1000 brand\n\n"
        msg += "OPPORTUNITIES:\n"
        msg += "• 3 butterflies scored 300+ but no canvas yet\n"
        msg += "• Wisdom Giants mentioned in 6 butterflies\n\n"
        msg += "Want me to explore any of these?"
        
        return msg
    
    def format_canvas_detail(self, canvas_name):
        """Format detailed canvas status"""
        msg = f"📊 {canvas_name.upper()} CANVAS STATUS:\n\n"
        msg += "AsianTel AI Strategy moved to AMBER. Here's why:\n\n"
        msg += "🟡 Budget concerns:\n"
        msg += "• Original: $2M\n"
        msg += "• Current: $3.2M (+60%)\n"
        msg += "• Cause: Scope creep Phase 2\n\n"
        msg += "I'VE ALREADY:\n"
        msg += "✅ Flagged in canvas\n"
        msg += "✅ Updated traffic lights\n"
        msg += "✅ Drafted email to John\n\n"
        msg += "NEED FROM YOU:\n"
        msg += "Reduce scope or increase budget?\n\n"
        msg += "I can:\n"
        msg += "A) Schedule call with John\n"
        msg += "B) Create revised scope doc\n"
        msg += "C) Run numbers on phased approach\n\n"
        msg += "Reply A, B, or C"
        
        return msg
    
    def send_morning_text(self):
        """Send Grace's morning check-in"""
        message, priorities = self.format_morning_message()
        
        # Save priorities to state
        state = self.load_state()
        state["current_priorities"] = priorities
        state["completed_today"] = []
        self.save_state(state)
        
        # Send SMS
        self.send_sms(TIM_PHONE, message)
        print(f"[{datetime.now()}] Grace sent morning check-in")
    
    def send_evening_text(self):
        """Send Grace's evening summary"""
        message = self.format_evening_message()
        self.send_sms(TIM_PHONE, message)
        print(f"[{datetime.now()}] Grace sent evening summary")

# Initialize Grace
grace = Grace()

# Flask app for receiving SMS responses
app = Flask(__name__)

@app.route("/sms", methods=['POST'])
def handle_sms():
    """Handle incoming SMS from Tim"""
    incoming_msg = request.values.get('Body', '').strip()
    incoming_msg_lower = incoming_msg.lower()
    from_number = request.values.get('From', '')
    
    # Only respond to Tim's number
    if from_number != TIM_PHONE:
        return "Unauthorized", 403
    
    state = grace.load_state()
    priorities = state.get("current_priorities", [])
    
    response_msg = ""
    
    # Handle commands
    if incoming_msg_lower in ['1', '2', '3']:
        idx = int(incoming_msg_lower) - 1
        if idx < len(priorities):
            action = priorities[idx]
            response_msg = f"✅ On it! Working on:\n{action['action']}\n\n"
            response_msg += "I'll execute and report back shortly."
            
            # Mark as completed
            state["completed_today"].append(action["id"])
            grace.save_state(state)
    
    elif incoming_msg_lower == 'all':
        response_msg = "✅ Executing all 3 priorities!\n\n"
        response_msg += "I'll work through them and update you on each.\n\n"
        response_msg += "You focus on the big picture. I've got the details. 💪"
        
        # Mark all as completed
        state["completed_today"].extend([p["id"] for p in priorities])
        grace.save_state(state)
    
    elif incoming_msg_lower == 'skip':
        # Get next 3 priorities
        all_actions = grace.load_action_items()
        completed_ids = state.get("completed_today", [])
        remaining = [a for a in all_actions if a["id"] not in completed_ids]
        next_3 = remaining[3:6] if len(remaining) > 3 else remaining
        
        response_msg = "NEXT 3 PRIORITIES:\n\n"
        for i, action in enumerate(next_3, 1):
            response_msg += f"{i}. {action['action']}\n"
            response_msg += f"   Est: {action['est_time']}\n\n"
        
        state["current_priorities"] = next_3
        grace.save_state(state)
    
    elif incoming_msg_lower == 'later':
        response_msg = "No problem! I'll check back this evening at 8pm.\n\n"
        response_msg += "Take your time. I'm here when you need me. 👍"
    
    elif incoming_msg_lower == 'status':
        completed = len(state.get("completed_today", []))
        open_count = len(grace.load_action_items())
        canvas_health = grace.get_canvas_health()
        response_msg = f"📊 STATUS UPDATE:\n\n"
        response_msg += f"✅ Completed today: {completed}\n"
        response_msg += f"📋 Open actions: {open_count}\n"
        response_msg += f"🔴 Red canvases: {canvas_health['red']}\n"
        response_msg += f"⚫ Active canvases: {canvas_health['black']}"
    
    elif incoming_msg_lower == 'help':
        response_msg = "GRACE'S COMMANDS:\n\n"
        response_msg += "QUICK:\n"
        response_msg += "1, 2, 3 - Do action\n"
        response_msg += "all - Do all 3\n"
        response_msg += "skip - Next 3\n"
        response_msg += "later - Check evening\n"
        response_msg += "status - Show progress\n\n"
        response_msg += "CONVERSATIONAL:\n"
        response_msg += "\"Grace, what's up?\"\n"
        response_msg += "\"Show me red canvases\"\n"
        response_msg += "\"What patterns do you see?\"\n"
        response_msg += "\"What's up with [canvas]?\""
    
    else:
        # Try conversational query
        response_msg = grace.handle_conversational_query(incoming_msg)
    
    # Send response
    grace.send_sms(TIM_PHONE, response_msg)
    
    return "OK", 200

@app.route("/health", methods=['GET'])
def health():
    """Health check endpoint"""
    return {
        "status": "healthy", 
        "grace": "flying",
        "timestamp": datetime.now().isoformat()
    }

def main():
    """Main function"""
    print("🦋 GRACE: Cloud Butterfly Executive Manager")
    print(f"Born: {grace.birthday}")
    print(f"Managing butterflies for: {TIM_PHONE}")
    print(f"SMS enabled: {client is not None}")
    
    # Schedule daily check-ins
    schedule.every().day.at("07:00").do(grace.send_morning_text)
    schedule.every().day.at("20:00").do(grace.send_evening_text)
    
    print("\nScheduled check-ins:")
    print("- Morning: 7:00 AM MST")
    print("- Evening: 8:00 PM MST")
    print("\nGrace is ready! Let's keep those butterflies flying. 🦋")
    print("Webhook endpoint: /sms")
    
    # For testing, send morning text now
    if os.getenv("TEST_MODE") == "true":
        print("\n[TEST MODE] Sending morning check-in now...")
        grace.send_morning_text()

if __name__ == "__main__":
    main()
