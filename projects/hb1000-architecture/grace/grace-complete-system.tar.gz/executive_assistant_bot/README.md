# Executive Assistant Daily Bot

Your personal SMS assistant for managing Cloud Butterfly action items.

## What It Does

**Morning (7:00 AM MST):**
Texts you the top 3 priorities from your Cloud Butterfly action items

**Interactive:**
You reply with simple commands (1, 2, 3, all, skip, later)

**Evening (8:00 PM MST):**
Sends you a summary of the day and tomorrow's priorities

## Setup Instructions

### 1. Get Twilio Account
- Sign up at https://www.twilio.com
- Get a phone number for the bot
- Copy your Account SID and Auth Token

### 2. Set Environment Variables
```bash
export TWILIO_ACCOUNT_SID="your_account_sid"
export TWILIO_AUTH_TOKEN="your_auth_token"
export TWILIO_PHONE_NUMBER="+1234567890"
```

### 3. Run the Bot
```bash
cd /home/ubuntu/executive_assistant_bot
python3 assistant_bot.py
```

### 4. Set Up Webhook
- In Twilio console, configure your phone number's webhook
- Point to: https://your-server.com/sms
- Method: POST

### 5. Deploy (Optional)
Deploy to a server that runs 24/7 to receive scheduled texts

## Commands

Reply to bot messages with:

- **1, 2, 3** — Execute action by number
- **all** — Execute all 3 top priorities
- **skip** — Show next 3 priorities
- **later** — Snooze until evening
- **status** — Show today's progress
- **help** — Show command list

## Example Conversation

**Bot (7:00 AM):**
```
Good morning Tim! ☀️

TOP 3 FOR TODAY:

1. Order 50 HB1000 ball caps (Amazon distributor)
   Source: Day 8, 🦋#84
   Est: 30 min

2. Create Application Genie Lean Canvas
   Source: Day 8, 🦋#80
   Est: 45 min

3. Email John Frank about farmers market
   Source: Day 8, 🦋#82
   Est: 15 min

Reply: 1, 2, 3, all, skip, or later
```

**You:** `1`

**Bot:**
```
✅ Working on: Order 50 HB1000 ball caps

I'll execute this and report back shortly.
```

## Integration with Cloud Butterfly

The bot automatically:
- Reads your Action Items Index
- Prioritizes based on butterfly scores
- Updates completion status
- Syncs with your daily reports

## Files

- `assistant_bot.py` — Main bot implementation
- `bot_state.json` — Current state (auto-created)
- `SYSTEM_DESIGN.md` — Technical design document
- `README.md` — This file

## Next Steps

1. Set up Twilio account
2. Configure environment variables
3. Test in demo mode first
4. Deploy to production server
5. Start receiving daily texts!

---

**Your Cloud Butterfly system now runs in your pocket. 📱🦋**
