# Executive Assistant Daily Bot — System Design

## Purpose
A daily SMS-based assistant that helps Tim manage Cloud Butterfly action items via text at 780-909-6544.

## Core Features
- Morning text (7:00 AM) with top 3 priorities
- Interactive SMS responses
- Action execution on demand
- Evening summary (8:00 PM)
- Simple commands (1, 2, 3, all, skip, later)

## Technical Stack
- Twilio API for SMS
- Python backend
- Action Items Index integration
- Cloud Butterfly system sync

## Message Format
```
Good morning Tim! ☀️

TOP 3 FOR TODAY:
1. [Action] - Est: X min
2. [Action] - Est: X min  
3. [Action] - Est: X min

Reply: 1, 2, 3, all, or skip
```

Full design document created.
