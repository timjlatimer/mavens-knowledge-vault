#!/usr/bin/env python3
"""
Executive Assistant Daily Bot
Manages Cloud Butterfly action items via SMS
"""

import os
import json
from datetime import datetime
from twilio.rest import Client
from flask import Flask, request
import schedule
import time

# Configuration
TIM_PHONE = "+17809096544"
BOT_PHONE = os.getenv("TWILIO_PHONE_NUMBER", "")  # Set via environment variable
TWILIO_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")

# Initialize Twilio client
client = Client(TWILIO_SID, TWILIO_TOKEN) if TWILIO_SID and TWILIO_TOKEN else None

# State management
state_file = "/home/ubuntu/executive_assistant_bot/bot_state.json"

def load_state():
    """Load bot state from file"""
    if os.path.exists(state_file):
        with open(state_file, 'r') as f:
            return json.load(f)
    return {
        "current_priorities": [],
        "completed_today": [],
        "conversation_context": {},
        "last_update": None
    }

def save_state(state):
    """Save bot state to file"""
    state["last_update"] = datetime.now().isoformat()
    with open(state_file, 'w') as f:
        json.dump(state, f, indent=2)

def load_action_items():
    """Load action items from Cloud Butterfly system"""
    # This would read from your Action Items Index
    # For now, returning mock data
    return [
        {
            "id": 84,
            "action": "Order 50 HB1000 ball caps (Amazon distributor)",
            "source": "Day 8, 🦋#84",
            "priority_score": 85,
            "est_time": "30 min"
        },
        {
            "id": 89,
            "action": "Create Application Genie Lean Canvas",
            "source": "Day 8, 🦋#80",
            "priority_score": 92,
            "est_time": "45 min"
        },
        {
            "id": 87,
            "action": "Email John Frank about farmers market in Wetaskiwin",
            "source": "Day 8, 🦋#82",
            "priority_score": 75,
            "est_time": "15 min"
        }
    ]

def get_top_priorities(n=3):
    """Get top N priority actions"""
    actions = load_action_items()
    sorted_actions = sorted(actions, key=lambda x: x["priority_score"], reverse=True)
    return sorted_actions[:n]

def send_sms(to_number, message):
    """Send SMS via Twilio"""
    if not client:
        print(f"[DEMO MODE] Would send to {to_number}:")
        print(message)
        print("-" * 50)
        return None
    
    try:
        message = client.messages.create(
            body=message,
            from_=BOT_PHONE,
            to=to_number
        )
        return message.sid
    except Exception as e:
        print(f"Error sending SMS: {e}")
        return None

def format_morning_message():
    """Format the morning priority message"""
    priorities = get_top_priorities(3)
    
    message = "Good morning Tim! ☀️\n\n"
    message += "TOP 3 FOR TODAY:\n\n"
    
    for i, action in enumerate(priorities, 1):
        message += f"{i}. {action['action']}\n"
        message += f"   Source: {action['source']}\n"
        message += f"   Est: {action['est_time']}\n\n"
    
    message += "Reply: 1, 2, 3, all, skip, or later"
    
    return message, priorities

def format_evening_message():
    """Format the evening summary message"""
    state = load_state()
    completed = len(state.get("completed_today", []))
    
    message = "Evening Tim! 🌙\n\n"
    message += "TODAY'S PROGRESS:\n"
    message += f"✅ Completed: {completed} actions\n"
    message += f"📋 Open: {len(load_action_items())} actions\n\n"
    message += "TOMORROW'S TOP 3:\n"
    
    priorities = get_top_priorities(3)
    for i, action in enumerate(priorities, 1):
        message += f"{i}. {action['action'][:50]}...\n"
    
    message += "\nReply 'yes' to confirm or 'change' to adjust."
    
    return message

def send_morning_text():
    """Send morning priority text"""
    message, priorities = format_morning_message()
    
    # Save priorities to state
    state = load_state()
    state["current_priorities"] = priorities
    state["completed_today"] = []
    save_state(state)
    
    # Send SMS
    send_sms(TIM_PHONE, message)
    print(f"[{datetime.now()}] Morning text sent")

def send_evening_text():
    """Send evening summary text"""
    message = format_evening_message()
    send_sms(TIM_PHONE, message)
    print(f"[{datetime.now()}] Evening text sent")

# Flask app for receiving SMS responses
app = Flask(__name__)

@app.route("/sms", methods=['POST'])
def handle_sms():
    """Handle incoming SMS from Tim"""
    incoming_msg = request.values.get('Body', '').strip().lower()
    from_number = request.values.get('From', '')
    
    # Only respond to Tim's number
    if from_number != TIM_PHONE:
        return "Unauthorized", 403
    
    state = load_state()
    priorities = state.get("current_priorities", [])
    
    response_msg = ""
    
    # Handle commands
    if incoming_msg in ['1', '2', '3']:
        idx = int(incoming_msg) - 1
        if idx < len(priorities):
            action = priorities[idx]
            response_msg = f"✅ Working on: {action['action']}\n\n"
            response_msg += "I'll execute this and report back shortly."
            
            # Mark as completed
            state["completed_today"].append(action["id"])
            save_state(state)
    
    elif incoming_msg == 'all':
        response_msg = "✅ Executing all 3 priorities!\n\n"
        response_msg += "I'll work through them and update you on each."
        
        # Mark all as completed
        state["completed_today"].extend([p["id"] for p in priorities])
        save_state(state)
    
    elif incoming_msg == 'skip':
        # Get next 3 priorities
        all_actions = load_action_items()
        completed_ids = state.get("completed_today", [])
        remaining = [a for a in all_actions if a["id"] not in completed_ids]
        next_3 = remaining[3:6] if len(remaining) > 3 else remaining
        
        response_msg = "NEXT 3 PRIORITIES:\n\n"
        for i, action in enumerate(next_3, 1):
            response_msg += f"{i}. {action['action']}\n"
            response_msg += f"   Est: {action['est_time']}\n\n"
        
        state["current_priorities"] = next_3
        save_state(state)
    
    elif incoming_msg == 'later':
        response_msg = "No problem! I'll check back this evening at 8pm. 👍"
    
    elif incoming_msg == 'status':
        completed = len(state.get("completed_today", []))
        open_count = len(load_action_items())
        response_msg = f"📊 STATUS:\n✅ Completed today: {completed}\n📋 Open: {open_count}"
    
    elif incoming_msg == 'help':
        response_msg = "COMMANDS:\n"
        response_msg += "1, 2, 3 - Do action\n"
        response_msg += "all - Do all 3\n"
        response_msg += "skip - Next 3\n"
        response_msg += "later - Check evening\n"
        response_msg += "status - Show progress\n"
        response_msg += "help - This list"
    
    else:
        response_msg = "I didn't understand that. Reply 'help' for commands."
    
    # Send response
    send_sms(TIM_PHONE, response_msg)
    
    return "OK", 200

@app.route("/health", methods=['GET'])
def health():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

def main():
    """Main function"""
    print("Executive Assistant Bot Starting...")
    print(f"Target phone: {TIM_PHONE}")
    print(f"Twilio configured: {client is not None}")
    
    # Schedule daily texts
    schedule.every().day.at("07:00").do(send_morning_text)
    schedule.every().day.at("20:00").do(send_evening_text)
    
    print("\nScheduled tasks:")
    print("- Morning text: 7:00 AM MST")
    print("- Evening text: 8:00 PM MST")
    print("\nBot ready! Webhook endpoint: /sms")
    
    # For testing, send morning text now
    if os.getenv("TEST_MODE") == "true":
        print("\n[TEST MODE] Sending morning text now...")
        send_morning_text()

if __name__ == "__main__":
    main()
